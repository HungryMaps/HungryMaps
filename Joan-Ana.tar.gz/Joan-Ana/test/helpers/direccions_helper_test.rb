require 'test_helper'

class DireccionsHelperTest < ActionView::TestCase
end
