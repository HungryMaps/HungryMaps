require 'test_helper'

class ProvinsHelperTest < ActionView::TestCase
end
