require 'test_helper'

class CategorsHelperTest < ActionView::TestCase
end
