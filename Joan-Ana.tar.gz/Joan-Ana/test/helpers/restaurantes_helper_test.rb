require 'test_helper'

class RestaurantesHelperTest < ActionView::TestCase
end
