require 'test_helper'

class DistritosHelperTest < ActionView::TestCase
end
