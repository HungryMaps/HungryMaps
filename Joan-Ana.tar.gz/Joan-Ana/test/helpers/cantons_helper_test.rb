require 'test_helper'

class CantonsHelperTest < ActionView::TestCase
end
