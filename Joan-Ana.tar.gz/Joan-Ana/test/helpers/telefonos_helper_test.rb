require 'test_helper'

class TelefonosHelperTest < ActionView::TestCase
end
