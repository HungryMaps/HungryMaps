require 'test_helper'

class TipocomidasHelperTest < ActionView::TestCase
end
