require 'test_helper'

class RestauranteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
