require 'test_helper'

class CantonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
