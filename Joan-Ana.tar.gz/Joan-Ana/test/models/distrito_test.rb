require 'test_helper'

class DistritoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
