require 'test_helper'

class TelefonoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
