require 'test_helper'

class CategorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
